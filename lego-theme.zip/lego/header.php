<!DOCTYPE HTML>
<html>
<head <?php language_attributes(); ?>>
    <title><?php wp_title(''); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <?php
    lego_css_vars();

    wp_head();

    ?>
</head>
<body <?php body_class(); ?>>
<script>
</script>
<div id="root">
    <div class="app">
        <div class="app_main">
            <header id="header" class="header<?php echo is_front_page() ? ' bg_white' : ''; ?>">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2">
                            <div class="logo header-logo">
                                <?php the_lego_logo(); ?>
                                <h2>Its Header</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <main>