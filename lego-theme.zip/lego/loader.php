<?php
//debug function for var_dump()
function debug($bug)
{
	echo '<pre style="padding: 15px; background: #000; display:block; width: 100%; color: #fff;">';
	var_dump($bug);
	echo '</pre>';
}


require_once __DIR__ . '/inc/bootstrap.php';

function includeFilesInDir($directory, $isChild = false) {
	$dirPath = ($isChild) ? get_stylesheet_directory() . '/' . $directory : get_template_directory() . '/' . $directory;

	// Get the list of files and directories in the current directory
	$contents = scandir($dirPath);

	// Loop through the list
	foreach ($contents as $item) {
		// Exclude '.' and '..' which represent the current and parent directories
		if ($item != "." && $item != "..") {
			$path = $dirPath . '/' . $item;

			// Check if the item is a file with a .php extension
			if (is_file($path) && pathinfo($path, PATHINFO_EXTENSION) === 'php') {
				include $path;
			} elseif (is_dir($path)) {
				// If the item is a directory, recursively include PHP files in it
				includeFilesInDir($directory . '/' . $item, $isChild);
			}
		}
	}
}

includeFilesInDir('functions');
