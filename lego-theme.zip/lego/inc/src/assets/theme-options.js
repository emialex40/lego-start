jQuery(document).ready(function ($) {

  $('.js-color').wpColorPicker()

  $('.fontsize').change(function () {
    let fontSize = $(this).val()
    let fontWeight = $(this).parent().siblings('div').find('.fontweight option:selected').val()

    if (fontWeight != 0) {
      let fontWeightStr = ',fw:' + fontWeight
      $(this).closest('.font-group').siblings('input').val('fz:' + fontSize + fontWeightStr)
    } else {
      $(this).closest('.font-group').siblings('input').val('fz:' + fontSize)
    }
  })

  $('.fontweight').change(function () {
    let fontWeight = $(this).children('option:selected').val()
    let $target = $(this).closest('.font-group').siblings('input').val()
    let targetStr = 'fw:' + fontWeight;

    if ($target != '') {
      let indexOfPart = $target.indexOf('fw:');

      if (indexOfPart !== -1) {
        console.log($target.substring(0, indexOfPart))
        // Remove the part and three characters after it
        targetStr = $target.substring(0, indexOfPart) + 'fw:' + fontWeight;
      } else {
        // Log a message if the part is not found
        targetStr = $target + ',fw:' + fontWeight;
      }
    }
    $(this).closest('.font-group').siblings('input').val(targetStr)
  })

  $('.theme-side ul li a').click(function() {
    let sectionID = $(this).data('tab')
    let section =  sectionID.replace('#', '');
    $(sectionID).addClass('active');
    $(sectionID).siblings().removeClass('active')
    $.cookie("activeSection", section);
  })

  $('#theme-form').submit(function (e) {
    e.preventDefault()
    let form = $(this).serialize()
    let data = { 'action': 'theme_form', 'form_data': form }

    $.ajax({
      url:     myajax.url,
      data:    data,
      type:    'post',
      success: function (response) {
        console.log(response)
        location.reload()
      },
      error: function(error) {
        // Обрабатываем ошибку
        console.log(error.responseText);
      }
    })
  })

  $('#reset').click(function () {
    let data = {'action': 'form_reset'}

    $.ajax({
      url:     myajax.url,
      data:    data,
      type:    'post',
      success: function (response) {
        location.reload()
      },
      error: function(error) {
        // Обрабатываем ошибку
        console.log(error.responseText);
      }
    })
  })

  $('.js-image-remove').click(function () {

    $(this).parent().siblings('#image-upload-field').val('')
    $(this).parent().remove()
  })

})