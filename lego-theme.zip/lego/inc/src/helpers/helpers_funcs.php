<?php

use App\BaseCss\BaseCss;
use App\LegoDB\LegoDB;

function slug_normalize( $slug ) {
	$slug = strtolower( $slug );
	$slug = str_replace( ' ', '_', $slug );

	return $slug;
}

function get_lego_options() {
	$db   = new LegoDB();
	$data = $db->get_options();

	return $data;
}

function set_lego_options( $data ) {
	$options = get_options( 'lego_options' );

	if ( isset( $options ) && ! empty( $options ) && is_array( $options ) && count( $options ) > 0 ) {
		update_option( 'lego_options', $data );
	} else {
		add_option( 'lego_options', $data );
	}
}

function lego_css_vars() {
	$css = new BaseCss();

	$css->generate_dynamic_css();

	return $css;
}

function the_lego_logo($additional = false) {
	$options   = get_lego_options();
	$img_url   = '';
	$site_name = get_bloginfo( 'name' );
	$logos = [];

	foreach ( $options as $key => $value ) {
		if ( strpos( $key, 'logo' ) !== false ) {

			$logos[$key] = $value;
		}
	}

	if ($additional && $logos['field_additional_logo'] != '') {
		$img_url = $logos['field_additional_logo'];
		debug($img_url);
	} else {
		$img_url = $logos['field_logo'];
	}

	if ( ! is_front_page() ) {
		if ($img_url != '') {
			echo '<a href="' . get_home_url() . '">';
			echo '<img src="' . $img_url . '" alt="' . $site_name . '" />';
			echo '</a>';
		}
	} else {
		if ($img_url != '') {
			echo '<img src="' . $img_url . '" alt="' . $site_name . '" />';
		}
	}
}
