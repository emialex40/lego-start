<?php

namespace App\Fields;

use App\LegoDB\LegoDB;
use App\LegoFonts\LegoFonts;

/**
 * Fields.
 */
class Fields
{
    public $db;

    public $data;

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $this->db = $db;
        $this->data = $data;

        $this->db = new LegoDB();
        $this->data = $this->db->get_options();
    }

    /**
     * text_field.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function text_field($name, $label = true)
    {
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['field_'.$slug] != '' ? $data['field_'.$slug] : '';

        if ($label) {
            echo '<label>'.$name.'</label>';
        }

        $field = '<input 
		id="'.$slug.'" 
		type="text" 
		name="field_'.$slug.'" 
		class="theme-field text-field field-'.$slug.'" 
		placeholder="'.$name.'" 
		value="'.$value.'">';

        return $field;
    }

    /**
     * email_field.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function email_field($name, $label = true)
    {
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['field_'.$slug] != '' ? $data['field_'.$slug] : '';

        if ($label) {
            echo '<label>'.$name.'</label>';
        }

        $field = '<input 
		id="'.$slug.'" 
		type="email" 
		name="field_'.$slug.'" 
		class="theme-field text-field field-'.$slug.'" 
		placeholder="'.$name.'" 
		value="'.$value.'">';

        return $field;
    }

    /**
     * imageUploadField.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function imageUploadField($name, $label = true)
    {
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['field_'.$slug] != '' ? $data['field_'.$slug] : '';

        if ($label) {
            echo '<label>'.$name.'</label>';
        }

        if (isset($value) && !empty($value)) {
            ?>
<div class="theme-img-preview" style="width: 150px; height: 150px; overflow: hidden;">
    <a href="javascript:;" class="js-image-remove">X</a>
    <img src="<?php echo $value; ?>" alt="" />
</div>
<?php
        } ?>
<input id="image_<?php echo $slug; ?>" type="text" name="field_<?php echo $slug; ?>"
    class="regular-text image-upload-field" value="<?php echo esc_url($value); ?>" style="display: none;">
<input id="imgbtn_<?php echo $slug; ?>" type="button" class="button button-secondary upload-image-button"
    value="<?php _e('Upload Image', 'lego-admin'); ?>">
<script>
jQuery(document).ready(function($) {
    $('#imgbtn_<?php echo $slug; ?>').click(function() {

        var mediaUploader
        mediaUploader = wp.media.frames.file_frame = wp.media({
            title: 'Choose Image',
            button: {
                text: 'Choose Image',
            },
            multiple: false,
        })
        mediaUploader.on('select', function() {
            var attachment = mediaUploader.state().get('selection').first().toJSON()
            $('#image_<?php echo $slug; ?>').val(attachment.url)
            $('#imgbtn_<?php echo $slug; ?>').append(
                '<div class="theme-img-preview" style="width: 150px; height: 150px; overflow: hidden;">' +
                '<a href="javascript:;" class="js-image-remove">X</a>' +
                '<img src="' + attachment.url + '" alt="" />' +
                '</div>',
            )
        })
        mediaUploader.open()
    })
})
</script>
<?php
    }

    /**
     * pickerField.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function pickerField($name, $label = true)
    {
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['color_field_'.$slug] != '' ? $data['color_field_'.$slug] : '';

        if ($label) {
            echo '<label>'.$name.'</label>';
        } ?>
<input type="text" name="color_field_<?php echo $slug; ?>" value="<?php echo esc_attr($value); ?>"
    class="color-field color-filed-<?php echo $slug; ?> js-color" data-default-color="#ffffff" />
<?php
    }

    /**
     * number_field.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function number_field($name, $label = true)
    {
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['field_'.$slug] != '' ? $data['field_'.$slug] : '';

        if ($label) {
            echo '<label>'.$name.'</label>';
        }

        $field = '<input 
		id="'.$slug.'" 
		type="number" 
		name="field_'.$slug.'" 
		class="theme-field text-field field-'.$slug.'" 
		placeholder="'.$name.'" 
		value="'.$value.'">';

        return $field;
    }

    /**
     * checkbox_field.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function checkbox_field($name, $label = true)
    {
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['field_'.$slug] != '' ? $data['field_'.$slug] : '';

        if ($label) {
            echo '<label>'.$name.'</label>';
        }

        $field = '<input 
		id="'.$slug.'" 
		type="checkbox" 
		name="field_'.$slug.'" 
		class="theme-field text-field field-'.$slug.'" 
		placeholder="'.$name.'" 
		value="'.$value.'">';

        return $field;
    }

    /**
     * fileField.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function fileField($name, $label = true)
    {
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['file_field_'.$slug] != '' ? $data['file_field_'.$slug] : '';

        if ($label) {
            echo '<label>'.$name.'</label>';
        }

        // Виводимо поле для вибору файлу
        echo '<input type="text" name="file_field_'.$slug.'" id="file_field_'.$slug.'" value="'.esc_attr($value).'" class="regular-text" />';
        echo '<input type="button" class="button file_field_'.$slug.'_btn" value="Вибрати файл" id="custom_file_upload_button" />'; ?>
<script>
jQuery(document).ready(function($) {
    $('.file_field_<?php echo $slug; ?>_btn').click(function(e) {
        e.preventDefault()

        var custom_file_frame = wp.media({
            title: 'Виберіть файл',
            button: {
                text: 'Вибрати файл',
            },
            multiple: false,
        })

        custom_file_frame.on('select', function() {
            var attachment = custom_file_frame.state().get('selection').first().toJSON()
            $('#file_field_<?php echo $slug; ?>').val(attachment.url)
        })

        custom_file_frame.open()
    })
})
</script>
<?php
    }

    /**
     * fontSelect.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function fontSelect($name, $label = true)
    {
        $fonts = new LegoFonts();
        $google_fonts = $fonts->getGoogleFontsList();
        $selected_fonts = [];
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['google_field_'.$slug] != '' ? $data['google_field_'.$slug] : '';

        if (!empty($value)) {
            $value_arr = explode(', ', $value);
        }

        if (!empty($google_fonts)) {
            if ($label) { ?>
<label><?php echo $name; ?></label>
<?php
            } ?>
<div id="font-suggestions">
    <?php foreach ($value_arr as $val) { ?>
    <span><?php echo $val; ?></span>
    <?php } ?>
</div>
<input type="text" id="font-data" name="google_field_<?php echo $slug; ?>" class="google_field_<?php echo $slug; ?>"
    value="<?php echo $value; ?>" style="display: none;">
<input type="text" id="font-search" name="font-search" class="regular-text" placeholder="Enter font name">

<script>
jQuery(document).ready(function($) {
    var availableFonts = <?php echo json_encode($google_fonts); ?>;

    $('#font-search').autocomplete({
        source: availableFonts,
        minLength: 1,
        select: function(event, ui) {
            var selectedFonts = ui.item.value;
            var oldValue = $('#font-data').val()
            var oldText = $('#font-suggestions').html()
            var includesSubString = oldValue.includes(selectedFonts);

            if (!includesSubString) {
                if (oldValue != '' && oldText != '') {

                    $('#font-data').val(oldValue + ', ' + selectedFonts);
                    $('#font-suggestions').html(oldText + '<span>' + selectedFonts + '</span>')
                } else {
                    $('#font-data').val(selectedFonts);
                    $('#font-suggestions').html('<span>' + selectedFonts + '</span>')
                }
            } else {
                return false
            }


        }
    });

    $('#font-suggestions span').click(function() {
        var substringToRemove = $(this).text()
        var oldValue = $('#font-data').val()
        var newValue = oldValue.replace(substringToRemove, '').replace(/,+/g, '');
        $('#font-data').val(newValue)
        $('#font-suggestions span:contains("' + substringToRemove + '")').remove();
    })
});
</script>

<?php
        } else {
            echo 'Не вдалося отримати список шрифтів.';
        }
    }

    /**
     * fontSizeGroup.
     *
     * @param mixed name
     * @param mixed label
     *
     * @return void
     */
    public function fontSizeGroup($name, $label = true)
    {
        $slug = slug_normalize($name);
        $data = $this->data;
        $value = $data['fontgroup_'.$slug] != '' ? $data['fontgroup_'.$slug] : '';

        $valueArr = explode(',', $value);
        $fz_value = explode(':', $valueArr[0])[1];
        $fw_value = explode(':', $valueArr[1])[1];
        $optionArr = ['0', '300', '400', '500', '600', '700', '900'];

        if ($label) {
            echo '<label>'.$name.'</label>';
        } ?>
<input id="fontgroup_<?php echo $slug; ?>" type="text" name="fontgroup_<?php echo $slug; ?>"
    class="theme-field text-field field-<?php echo $slug; ?>" value="<?php echo $value; ?>" style="display: none;">
<div class="font-group">
    <div>
        <label>Font Size</label>
        <input type="number" class="font-add fontsize" value="<?php echo $fz_value; ?>">
    </div>
    <div>
        <label>Font Weight</label>
        <select class="fontweight">
            <?php foreach ($optionArr as $option) {
            $selected = ($option == $fw_value) ? ' selected' : ''; ?>
            <?php if ($option == '0') { ?>
            <option value="<?php echo $option; ?>" <?php echo $selected; ?>>---</option>
            <?php } else { ?>
            <option value="<?php echo $option; ?>" <?php echo $selected; ?>><?php echo $option; ?></option>
            <?php } ?>
            <?php
        } ?>
        </select>
    </div>

</div>

<?php
    }
}
