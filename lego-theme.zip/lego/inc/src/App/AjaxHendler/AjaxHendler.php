<?php

namespace App\AjaxHendler;

use App\LegoDB\LegoDB;
use App\BaseCss\ScssSettings;
use App\LegoFonts\LegoFonts;

/**
 * AjaxHendler.
 */
class AjaxHendler
{
    private $lego_db;

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $lego_db = new LegoDB();
        $this->lego_db = $lego_db;
        add_action('wp_ajax_theme_form', [$this, 'form_ajax_request']);
        add_action('wp_ajax_form_reset', [$this, 'form_ajax_reset']);
    }

    /**
     * form_ajax_request.
     *
     * @return void
     */
    public function form_ajax_request()
    {
        if (defined('DOING_AJAX') && DOING_AJAX) {
            $data = [];
            $request = isset($_POST['form_data']) ? (string) $_POST['form_data'] : '';
            $request = urldecode($request);

            $request_arr = explode('&', $request);

            foreach ($request_arr as $arrs) {
                [$key, $value] = explode('=', $arrs, 2);
                $data[$key] = $value;
            }
            $response = serialize($data);

            $this->lego_db->save_options($data);

            $scss = new ScssSettings();
            $fonts = new LegoFonts();
            $db_data = $this->lego_db->get_options();
            $scss->scss_save();
            $fonts->setStyleVars();

            echo 'Success';

            wp_die();
        }
    }

    public function form_ajax_reset()
    {
        if (defined('DOING_AJAX') && DOING_AJAX) {
            $this->lego_db->save_options('');
        }
    }
}
