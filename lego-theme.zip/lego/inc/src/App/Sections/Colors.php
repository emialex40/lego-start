<?php

namespace App\Sections;

use App\Fields\Fields;
use App\OptionsMenu\OptionsMenu;
use App\Sections\Sections;

/**
 * Colors
 */
class Colors implements SectionInterface {
    
    /**
     * @var mixed menu
     */
    public $menu;
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	public function __construct() {
		$menu       = new OptionsMenu();
		$this->menu = $menu;
	}
	
	/**
	 * checkMenu
	 *
	 * @param mixed menu
	 *
	 * @return void
	 */
	public function checkMenu( $menu ) {
		$flag  = false;
		$array = $this->menu->get_menu( $menu );

		if ( is_array( $array ) && array_key_exists( 'colors', $array ) ) {
			$flag = true;
		}

		return $flag;
	}
	
	/**
	 * checkActive
	 *
	 * @return void
	 */
	public function checkActive() {
		$section = new Sections();
		$activeID = $section->getCookie();
		if (isset($activeID)) {
			$active = ($activeID == 'colors') ? ' active' : '';
		} else {
			$active = ' active';
		}

		return $active;
	}
	
	/**
	 * get_html
	 *
	 * @return void
	 */
	public function get_html() {
		$fields = new Fields();

		if ( $this->checkMenu( $this->menu->menu ) ) {
			$active = $this->checkActive();
			?>
<div id="colors" class="theme-tab theme-header<?php echo $active; ?>">
    <h3>UI Colors</h3>

    <h4>Base Colors</h4>
    <div class="row">
        <div class="col">
            <?php echo $fields->pickerField( 'Base Color 1' ) ?>
        </div>
        <div class="col">
            <?php echo $fields->pickerField( 'Base Color 2' ) ?>
        </div>
        <div class="col">
            <?php echo $fields->pickerField( 'Base Color 3' ) ?>
        </div>
        <div class="col">
            <?php echo $fields->pickerField( 'Base Color 4' ) ?>
        </div>
    </div>
    <h4>Font Colors</h4>
    <div class="row">
        <div class="col">
            <?php echo $fields->pickerField( 'Font Color 1' ) ?>
        </div>
        <div class="col">
            <?php echo $fields->pickerField( 'Font Color 2' ) ?>
        </div>

        <div class="col">
            <?php echo $fields->pickerField( 'Font Color 3' ) ?>
        </div>
        <div class="col">
            <?php echo $fields->pickerField( 'Font Color 4' ) ?>
        </div>
    </div>
</div>
<?php
		}
	}

}
