<?php

namespace App\Sections;

use App\Fields\Fields;
use App\OptionsMenu\OptionsMenu;

class Fonts
{
    /**
     * @var mixed menu
     */
    public $menu;

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $menu = new OptionsMenu();
        $this->menu = $menu;
    }

    /**
     * checkMenu.
     *
     * @param mixed menu
     *
     * @return void
     */
    public function checkMenu($menu)
    {
        $flag = false;
        $array = $this->menu->get_menu($menu);

        if (is_array($array) && array_key_exists('fonts', $array)) {
            $flag = true;
        }

        return $flag;
    }

    /**
     * checkActive.
     *
     * @return void
     */
    public function checkActive()
    {
        $section = new Sections();
        $activeID = $section->getCookie();

        if (isset($activeID) && $activeID == 'fonts') {
            $active = ' active';
        } else {
            $active = '';
        }

        return $active;
    }

    /**
     * get_html.
     *
     * @return void
     */
    public function get_html()
    {
        $fields = new Fields();

        if ($this->checkMenu($this->menu->menu)) {
            $active = $this->checkActive(); ?>
<div id="fonts" class="theme-tab theme-header<?php echo $active; ?>">
    <h3>UI Fonts</h3>

    <h4>Google Fonts</h4>
    <div class="row row-google">
        <div class="col">
            <?php echo $fields->fontSelect('Google Font'); ?>
        </div>
    </div>
    <h4>Font Options</h4>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('H1'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('H2'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('H3'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('H4'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('H5'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('H6'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('P'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('strong'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('a'); ?>
        </div>
    </div>
    <div class="row">
        <div class="col">
            <?php echo $fields->fontSizeGroup('List'); ?>
        </div>
    </div>
</div>
<?php
        }
    }
}
