<?php

namespace App\Sections;

use App\Sections\Colors;
use App\Sections\Fonts;
use App\Sections\Header;
use App\Sections\Footer;


/**
 * Sections
 */
class Sections {
	
	/**
	 * get_sections_html
	 *
	 * @return void
	 */
	public function get_sections_html() {
		$colors = new Colors();
		$fonts = new Fonts();
		$header  = new Header();
        $footer = new Footer();

		$colors->get_html();
		$fonts->get_html();
		$header->get_html();
		$footer->get_html();
	}
	
	/**
	 * save_button
	 *
	 * @return void
	 */
	public function save_button() {
		?>
<div class="row button-row">
    <input type="submit" class="button button-primary" value="<?php echo _e( 'Save Button', 'lego-admin' ); ?>">
    <a id="reset" href="javascript:;"><?php _e('Reset Options'); ?></a>
</div>
<?php
	}
    
    /**
     * getCookie
     *
     * @return void
     */
    public function getCookie() {
	    $cookie_value =$_COOKIE['activeSection'] ?? $_COOKIE['your_cookie_name'];


        return $cookie_value;
    }

}
