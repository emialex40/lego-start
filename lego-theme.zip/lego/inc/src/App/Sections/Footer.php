<?php

namespace App\Sections;

use App\OptionsMenu\OptionsMenu;
use App\Fields\Fields;

class Footer implements SectionInterface
{
    /**
     * @var mixed menu
     */
    public $menu;

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $menu = new OptionsMenu();
        $this->menu = $menu;
    }

    /**
     * checkMenu.
     *
     * @param mixed menu
     *
     * @return void
     */
    public function checkMenu($menu)
    {
        $flag = false;
        $array = $this->menu->get_menu($menu);

        if (is_array($array) && array_key_exists('footer', $array)) {
            $flag = true;
        }

        return $flag;
    }

    /**
     * checkActive.
     *
     * @return void
     */
    public function checkActive()
    {
        $section = new Sections();
        $activeID = $section->getCookie();

        if (isset($activeID) && $activeID == 'footer') {
            $active = ' active';
        } else {
            $active = '';
        }

        return $active;
    }

    /**
     * get_html.
     *
     * @return void
     */
    public function get_html()
    {
        $fields = new Fields();

        if ($this->checkMenu($this->menu->menu)) {
            $active = $this->checkActive(); ?>
<div id="footer" class="theme-tab theme-header<?php echo $active; ?>">
    <h3>Footer UI Options</h3>
    <div class="row">
        <div class="col">
            <?php echo $fields->text_field('Copyright'); ?>
        </div>

    </div>
</div>
<?php
        }
    }
}
