<?php

namespace App\Sections;

interface SectionInterface
{
    /**
     * checkMenu.
     *
     * @param mixed menu
     *
     * @return void
     */
    public function checkMenu($menu);

    /**
     * checkActive.
     *
     * @return void
     */
    public function checkActive();

    /**
     * get_html.
     *
     * @return void
     */
    public function get_html();
}
