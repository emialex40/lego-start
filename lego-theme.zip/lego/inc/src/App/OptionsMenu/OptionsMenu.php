<?php

namespace App\OptionsMenu;

/**
 * OptionsMenu.
 */
class OptionsMenu
{
    /**
     * @var mixed menu
     */
    public $menu = [
        'colors' => 'UI Colors ',
        'fonts' => 'UI Fonts',
        'header' => 'UI Header',
        'footer' => ' UI Footer',
    ];

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $menu = $this->menu;
    }

    /**
     * get_menu.
     *
     * @param mixed arr
     *
     * @return void
     */
    public function get_menu($arr)
    {
        return $arr;
    }

    /**
     * get_menu_html.
     *
     * @param mixed arr
     *
     * @return void
     */
    public function get_menu_html($arr)
    {
        $html = '<ul>';
        foreach ($arr as $key => $value) {
            $html .= '<li>';
            $html .= '<a href="javascript:;" data-tab="#'.$key.'">'.$value.'</a>';
            $html .= '</li>';
        }
        $html .= '</ul>';

        echo $html;
    }
}
