<?php

namespace App\Options;

use App\OptionsMenu\OptionsMenu;
use App\Sections\Sections;

/**
 * Options
 */
class Options {
	
	/**
	 * __construct
	 *
	 * @return void
	 */
	function __construct() {
		add_action( 'admin_menu', [ $this, 'theme_option_init' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'theme_admin_scripts' ] );
	}
	
	/**
	 * theme_option_init
	 *
	 * @return void
	 */
	public function theme_option_init() {
		add_menu_page( 'Theme UI Options', 'Theme UI', 'manage_options', 'theme-options', [ $this, 'theme_options_page' ], 'dashicons-admin-generic', 3 );
	}
	
	/**
	 * theme_options_page
	 *
	 * @return void
	 */
	public function theme_options_page() {
		$menu     = new OptionsMenu();
		$sections = new Sections();
		?>

<div class="theme">
    <h2><?php _e( 'Theme UI Option', 'lego-admin' ); ?></h2>

    <div class="theme-wrap">
        <div class="theme-row">
            <div class="theme-side">
                <?php $menu->get_menu_html( $menu->menu ); ?>
            </div>
            <form id="theme-form" action="/wp-admin/admin.php?page=theme-options" method="post">
                <div class="theme-content">
                    <?php $sections->get_sections_html(); ?>
                </div>
                <?php $sections->save_button(); ?>
            </form>
        </div>
    </div>
</div>

<?php
	}

	
	/**
	 * theme_admin_scripts
	 *
	 * @return void
	 */
	public function theme_admin_scripts() {
		wp_enqueue_media();
		wp_enqueue_script( 'theme-admin-script', get_template_directory_uri() . '/js/theme-admin-script.js', [ 'jquery' ], '', true );
	}

}
