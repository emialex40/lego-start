<?php

namespace App\LegoFonts;

use App\LegoDB\LegoDB;

class LegoFonts
{
    private $api_url;

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $api_url = 'https://www.googleapis.com/webfonts/v1/webfonts?key=AIzaSyC8kvM9FZ7VNO6DleKPufMWm2pAWHsBRXA';
        $this->api_url = $api_url;
        $this->enqueueGoogleFonts();
    }

    /**
     * getGoogleFontsList.
     *
     * @return void
     */
    public function getGoogleFontsList()
    {
        $response = wp_remote_get($this->api_url);

        if (is_wp_error($response)) {
            return [];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['items'])) {
            $fonts = [];

            foreach ($data['items'] as $font) {
                $fonts[] = $font['family'];
            }

            return $fonts;
        }

        return [];
    }

    /**
     * getFontsOptions.
     *
     * @return void
     */
    private function getFontsOptions()
    {
        $db = new LegoDB();
        $options = $db->get_options();
        $fonts_str = '';

        foreach ($options as $key => $value) {
            if (strpos($key, 'google_field') !== false) {
                $fonts_str = $value;
            }
        }

        $selected_fonts = explode(',', $fonts_str);
        $array = array_map('trim', $selected_fonts);

        return $array;
    }

    /**
     * enqueueGoogleFonts.
     *
     * @return void
     */
    public function enqueueGoogleFonts()
    {
        $selected_fonts = $this->getFontsOptions();
        $list = $this->getGoogleFontsList();

        $selected_fonts = array_map('trim', $selected_fonts);

        if (!empty($selected_fonts) && count($selected_fonts) > 0) {
            $font_query = implode('|', array_map('urlencode', $selected_fonts));
            $font_url = "https://fonts.googleapis.com/css?family=$font_query&display=swap";

            wp_enqueue_style('google-fonts', $font_url, [], null);
        }
    }

    /**
     * setStyleVars.
     *
     * @return void
     */
    public function setStyleVars()
    {
        $selected_options = $this->getFontsOptions();
        $path = get_template_directory().'/dev/sass/_mixins/_settings.scss';
        $content = file_get_contents($path);

        if ($content) {
            $scss = PHP_EOL;
            foreach ($selected_options as $option) {
                $optionVarName = strtolower(trim($option));
                $optionVarName = '$'.str_replace(' ', '_', $optionVarName).': ';
                $scss .= $optionVarName.'"'.$option.'" !default;'.PHP_EOL;
            }

            $newContent = $content.$scss;
            file_put_contents($path, $newContent);
        }
    }
}
