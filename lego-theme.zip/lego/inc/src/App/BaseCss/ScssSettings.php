<?php

namespace App\BaseCss;

use App\LegoDB\LegoDB;

/**
 * ScssSettings.
 */
class ScssSettings
{
    private $path;

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $path = get_template_directory().'/dev/sass/_mixins/_settings.scss';
        $this->path = $path;
    }

    /**
     * scss_get_file.
     *
     * @return void
     */
    private function scss_get_file()
    {
        $file = file_get_contents($this->path);

        return $file;
    }

    /**
     * getSearchTerm.
     *
     * @param mixed data
     * @param mixed term
     *
     * @return void
     */
    private function getSearchTerm($data, $term)
    {
        $results = array_filter($data, function ($key) use ($term) {
            return strpos($key, $term) !== false;
        }, ARRAY_FILTER_USE_KEY);

        return $results;
    }

    /**
     * scss_create_content.
     *
     * @param mixed data
     *
     * @var void
     *
     * @return void
     */
    public function scss_create_content($data)
    {
        $file = $this->scss_get_file();
        $searchTerms = ['color_field', 'fontgroup'];

        $scss = '';
        foreach ($searchTerms as $search_term) {
            $results = $this->getSearchTerm($data, $search_term);

            if ($results) {
                foreach ($results as $key => $value) {
                    $var_name = str_replace($search_term.'_', '', $key);
                    if ($search_term == 'color_field') {
                        $var_name = str_replace($search_term.'_', '', $key);
                        $scss .= '$'.$var_name.': var(--'.$var_name.') !default;'.PHP_EOL;
                    } elseif ($search_term == 'fontgroup') {
                        $name = str_replace($search_term.'_', '', $key);
                        $valArr = explode(',', $value);

                        foreach ($valArr as $val_arr) {
                            $prefix = explode(':', $val_arr)[0];
                            $val = explode(':', $val_arr)[1];

                            $var_name = $prefix.'_'.$name;
                            $scss .= '$'.$var_name.': var(--'.$var_name.') !default;'.PHP_EOL;
                        }
                    } else {
                        $var_name = str_replace($search_term.'_', '', $key);
                        $scss .= '$'.$var_name.': var(--'.$var_name.') !default;'.PHP_EOL;
                    }
                }
            }
        }

        return $scss;
    }

    /**
     * scss_save.
     *
     * @return void
     */
    public function scss_save()
    {
        $db = new LegoDB();
        $db_data = $db->get_options();
        $new_content = $this->scss_create_content($db_data);

        file_put_contents($this->path, $new_content);
    }
}
