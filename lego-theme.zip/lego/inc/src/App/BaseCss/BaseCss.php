<?php

namespace App\BaseCss;

use App\LegoDB\LegoDB;

/**
 * BaseCss.
 */
class BaseCss
{
    /**
     * generate_dynamic_css.
     *
     * @return void
     */
    public function generate_dynamic_css()
    {
        // Отримуємо налаштування або будь-які дані, які потрібно включити у динамічний CSS
        $dynamic_css = $this->get_dynamic_css();

        // Виводимо стилі в тегу style в розділі head
        echo '<style>'.$dynamic_css.'</style>';
    }

    /**
     * getSearchTerm.
     *
     * @param mixed term
     *
     * @return void
     */
    private function getSearchTerm($term)
    {
        $lego_db = new LegoDB();
        $data = $lego_db->get_options();

        $results = array_filter($data, function ($key) use ($term) {
            return strpos($key, $term) !== false;
        }, ARRAY_FILTER_USE_KEY);

        return $results;
    }

    /**
     * get_dynamic_css.
     *
     * @return void
     */
    private function get_dynamic_css()
    {
        $searchTerms = ['color_field', 'fontgroup'];

        $css = '';

        foreach ($searchTerms as $search_term) {
            $results = $this->getSearchTerm($search_term);

            if ($results) {
                $css .= ':root {';
                foreach ($results as $key => $value) {
                    if ($search_term == 'fontgroup') {
                        $name = str_replace($search_term.'_', '', $key);
                        $valueArr = explode(',', $value);

                        foreach ($valueArr as $val_arr) {
                            $prefix = explode(':', $val_arr)[0];
                            $val = explode(':', $val_arr)[1];

                            $var_name = $prefix.'_'.$name;

                            if ($prefix == 'fz') {
                                $val = $val.'px';
                            }
                            $css .= '--'.$var_name.': '.$val.'; ';
                        }
                    } else {
                        $var_name = str_replace($search_term.'_', '', $key);
                        $css .= '--'.$var_name.': '.$value.'; ';
                    }
                }
                $css .= '}';
            }
        }

        return $css;
    }
}
