<?php

namespace App\LegoDB;

class LegoDB
{
    private $table_name;

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        global $wpdb;
        $table_name = $wpdb->prefix.'lego_option';
        $this->table_name = $table_name;

        $this->create_table_if_not_exists();
    }

    /**
     * create_table_if_not_exists.
     *
     * @return void
     */
    private function create_table_if_not_exists()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // SQL-запит для створення таблиці, якщо вона не існує
        $sql = "CREATE TABLE IF NOT EXISTS $this->table_name (
            id INT NOT NULL AUTO_INCREMENT,
            options_data LONGTEXT,
            PRIMARY KEY (id)
        ) $charset_collate;";

        // Виконання SQL-запиту
        require_once ABSPATH.'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * save_options.
     *
     * @param mixed options
     *
     * @return void
     */
    public function save_options($options)
    {
        global $wpdb;

        // Перевірка, чи існує запис в таблиці
        $existing_row = $wpdb->get_row("SELECT * FROM $this->table_name LIMIT 1");

        // Серіалізація налаштувань
        $serialized_options = serialize($options);

        if ($existing_row) {
            $wpdb->update(
                $this->table_name,
                ['options_data' => $serialized_options],
                ['id' => $existing_row->id],
                ['%s'],
                ['%d']
            );
        } else {
            $wpdb->insert(
                $this->table_name,
                ['options_data' => $serialized_options],
                ['%s']
            );
        }
    }

    /**
     * get_options.
     *
     * @return void
     */
    public function get_options()
    {
        global $wpdb;

        // Отримуємо дані з таблиці
        $result = $wpdb->get_row("SELECT * FROM $this->table_name LIMIT 1");

        // Десеріалізація налаштувань
        $options = $result ? unserialize($result->options_data) : [];

        //		debug($options);

        return $options;
    }
}
