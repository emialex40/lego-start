<?php

namespace App\Lego;

use App\Options\Options;
use App\AjaxHendler\AjaxHendler;
use App\LegoFonts\LegoFonts;

class Lego
{
    private $current_theme;

    private $active_theme;

    /**
     * @var mixed version
     */
    private $version = '1.0.0';

    /**
     * __construct.
     *
     * @return void
     */
    public function __construct()
    {
        $current_theme = $this->current_theme;
        $active_theme = $this->active_theme;
        $version = $this->version;

        $this->check_version();
        $this->init();
    }

    /**
     * init.
     *
     * @return void
     */
    public function init()
    {
        new Options();
        new AjaxHendler();
        new LegoFonts();

        $this->add_uploads_constatnt();
        add_action('admin_enqueue_scripts', [$this, 'load_styles_scripts']);
        add_action('wp_head', [$this, 'generate_dynamic_css'], 100);
        add_filter('upload_mimes', [$this, 'upload_mimes']);
    }

    /**
     * check_version.
     *
     * @return void
     */
    public function check_version()
    {
        $this->current_theme = wp_get_theme();
        $this->active_theme = wp_get_theme('Lego');

        if ($this->current_theme->get('Name') !== $this->active_theme->get('Name')) {
            return;
        }
    }

    /**
     * load_styles_scripts.
     *
     * @return void
     */
    public function load_styles_scripts()
    {
        wp_enqueue_style('admin-lego-styles', get_template_directory_uri().'/inc/src/assets/theme-option.css');
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('jquery-cookie', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-cookie/1.4.1/jquery.cookie.min.js');
        wp_enqueue_style('jquery-ui-styles', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');

        wp_enqueue_script('jquery-ui-core');
        wp_enqueue_script('jquery-ui-autocomplete');
        wp_enqueue_script('admin-lego-scripts', get_template_directory_uri().'/inc/src/assets/theme-options.js', ['jquery', 'wp-color-picker'], '', true);
        wp_localize_script('jquery', 'myajax', [
            'url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('myajax-nonce'),
        ]);
    }

    /**
     * upload_mimes.
     *
     * @param mixed existing_mimes
     *
     * @return void
     */
    public function upload_mimes($existing_mimes)
    {
        $existing_mimes['svg'] = 'image/svg+xml';
        $existing_mimes['ttf'] = 'font/ttf';
        $existing_mimes['otf'] = 'font/otf';
        $existing_mimes['woff'] = 'font/woff';
        $existing_mimes['woff2'] = 'font/woff2';

        return $existing_mimes;
    }

    /**
     * add_uploads_constatnt.
     *
     * @return void
     */
    private function add_uploads_constatnt()
    {
        $config_path = ABSPATH.'wp-config.php';

        if (file_exists($config_path) && is_writable($config_path)) {
            $current_content = file_get_contents($config_path);
            $constant_to_check = "define('ALLOW_UNFILTERED_UPLOADS', true);";

            if (strpos($current_content, $constant_to_check) === false) {
                $new_content = $current_content.PHP_EOL.$constant_to_check;
                file_put_contents($config_path, $new_content);
            }
        }
    }
}
