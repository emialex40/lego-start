<?php

require_once __DIR__ . '/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'lego_register_required_plugins' );


function lego_register_required_plugins() {
	/*
	 * Array of plugin arrays. Required keys are name and slug.
	 * If the source is NOT from the .org repo, then source is also required.
	 */
	$source = __DIR__ . '/tgm-plugins';

	$plugins = [

		[
			'name'             => 'Advanced Custom Fields PRO',
			'slug'             => 'advanced-custom-fields-pro-main',
			'source'           => $source . '/advanced-custom-fields-pro-main.zip',
			'force_activation' => false,
			'required'         => false,
		],
		[
			'name'             => 'WPBakery Page Builder',
			'slug'             => 'js_composer',
			'source'           => $source . '/wp_bakery6100.zip',
			'force_activation' => false,
			'required'         => false,
		],

	];


	$config = [
		'id'           => 'lego-admin',                 // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '',                      // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'parent_slug'  => 'themes.php',            // Parent menu slug.
		'capability'   => 'edit_theme_options',    // Capability needed to view plugin install page, should be a capability associated with the parent menu used.
		'has_notices'  => true,                    // Show admin notices or not.
		'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false,                   // Automatically activate plugins after installation or not.
		'message'      => '',                      // Message to output right before the plugins table.


	];

	tgmpa( $plugins, $config );
}
