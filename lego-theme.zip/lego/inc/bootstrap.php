<?php

namespace App;

require_once __DIR__.'/vendor/autoload.php';

use App\Lego\Lego;

if (!defined('LEGO_VERSION')) {
    define('LEGO_VERSION', '1.0.0');
}

require_once __DIR__ . '/tgm/tgm_init.php';
require_once __DIR__ . '/src/helpers/helpers_funcs.php';


new Lego();
