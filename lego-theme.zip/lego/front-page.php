<?php
    get_header();

?>
<div class="container">
    <div class="colors-row">
        <div class="colors-row-item colors-row-item1"></div>
        <div class="colors-row-item colors-row-item2"></div>
        <div class="colors-row-item colors-row-item3"></div>
        <div class="colors-row-item colors-row-item4"></div>
    </div>
<h1>H1</h1>
<h2>H2</h2>
<h2>H3</h2>
<h4>H4</h4>
<h5>H5</h5>
<h6>H5</h6>

<p>It`s exemple for "p" tag. It`s exemple for "p" tag. It`s exemple for "p" tag.</p>
<strong>It`s exemple for "strong" tag.</strong>
<a href="#">Link</a>

<ul>
    <li>List</li>
    <li>List</li>
    <li>List</li>
    <li>List</li>
</ul>
</div>



<?php get_footer(); ?>  