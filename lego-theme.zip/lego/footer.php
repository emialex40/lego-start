

</main>
</div>
</div>
</div>

<footer id="footer" class="footer bg_dark">
    <div class="container">
        <h2>Its footer</h2>
    </div>

</footer>

<?php wp_footer(); ?>
</body>
</html>